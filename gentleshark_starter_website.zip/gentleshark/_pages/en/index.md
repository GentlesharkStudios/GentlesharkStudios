# Welcome to Gentleshark

**Indie game studio based in Germany.**

We create games with heart and narrative depth. Currently working on our first title.

[Learn more](/en/about/) | [Projects](/en/projects/) | [Contact](/en/contact/)