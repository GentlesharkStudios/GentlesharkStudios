# About Us

Gentleshark is an independent game studio based in Germany. We focus on story-driven games with emotional depth.