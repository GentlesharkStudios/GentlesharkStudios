# Über uns

Gentleshark ist ein unabhängiges Entwicklerstudio mit Sitz in Deutschland. Unser Fokus liegt auf narrativen Spielen mit emotionaler Tiefe.