# Willkommen bei Gentleshark

**Indie-Entwicklerstudio aus Deutschland.**

Wir entwickeln Spiele mit Charakter und Tiefe. Aktuell arbeiten wir an unserem ersten Titel.

[Mehr erfahren](/de/about/) | [Projekte](/de/projects/) | [Kontakt](/de/contact/)