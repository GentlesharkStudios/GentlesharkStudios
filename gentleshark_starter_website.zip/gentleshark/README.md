## Anleitung zur Veröffentlichung

1. Repository erstellen: `gentlesharkstudios.github.io`
2. Diese Dateien hochladen oder via Git pushen
3. GitHub Pages aktivieren (in den Repo-Einstellungen)
4. Website ist dann aufrufbar unter: https://gentlesharkstudios.github.io

Für Sprachumschaltung kannst du später Buttons oder Flags in die Navigation einfügen.